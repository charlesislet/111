# kb-extract：知識庫文件重點萃取

上傳檔案 → 解析 → 依長度選策略萃取重點 → 出處驗證 → 存成 JSON（供前端、問答與簡報大綱使用）。

## 安裝

```bash
pip install -e ".[anthropic,mineru,worker,dev]"     # 用 Claude API
pip install -e ".[openai,mineru,worker,dev]"        # 用 OpenAI 或地端 vLLM / Ollama
```

## 使用

```bash
export ANTHROPIC_API_KEY=...
kb-extract 年度報告.pdf -o 年度報告.json --audience "業務主管"

# 地端模型（vLLM / Ollama 的 OpenAI 相容端點）
export KB_PROVIDER=openai KB_BASE_URL=http://localhost:8000/v1
export KB_FAST_MODEL=qwen-small KB_STRONG_MODEL=qwen-large
kb-extract 合約.pdf
```

Python 內呼叫：

```python
from kb_extract import Extractor, ExtractConfig, MinerUParser, AnthropicClient

doc = MinerUParser().parse("年度報告.pdf", doc_id="doc-123")
insights = Extractor(AnthropicClient("claude-haiku-5-5"), AnthropicClient("claude-sonnet-5-5")).run(doc)
for p in insights.result.key_points:
    print(p.importance, p.point, p.source_pages, "✓" if p.verified else "未驗證")
```

背景任務（上傳後自動處理）：

```bash
celery -A kb_extract.tasks worker --concurrency=4
# 上傳 API 中：process_document.delay(doc_id, stored_path)
```

## 流程

| 步驟 | 模組 | 說明 |
|---|---|---|
| 解析 | `parsing.py` | MinerU（中文優先）、Docling、Markdown。輸出帶頁碼與標題層級的 Block；表格轉 Markdown |
| 選策略 | `extract.py` | 估算 token ≤ 30k 走單次萃取；超過走樹狀索引 |
| 建樹 | `tree.py` | 依標題建樹 → 過大葉節點依段落切分 → 由下往上摘要（PageIndex 式目錄樹） |
| Map | `extract.py` | 相鄰小章節合併成批，各批用小模型萃取 ≤ 5 個候選重點；頁碼超出該批範圍即丟棄 |
| Reduce | `extract.py` | 強模型依目錄樹摘要＋候選重點產出最終結果；清除候選以外的頁碼 |
| 驗證 | `verify.py` | 字元二元組重疊率夠高直接通過，否則小模型判斷；頁碼不存在直接不通過 |

設計對應 2026 研究：每次呼叫只輸出少量重點（幻覺集中在長輸出後段）；長文件一律先分節（摘要長度不隨原文成長）。

## 要接到你們系統的地方

- `tasks.py` 的 `update_status`、`save_insights`：改寫成資料庫寫入
- `prompts.py`：調整讀者、語氣、重點數量
- `ExtractConfig`：`single_pass_tokens`、`max_points`、`drop_unverified`
- MinerU 升級後，用一份樣本確認 `content_list.json` 欄位（`MinerUParser.from_content_list`）

## 測試

`pytest -q`：用假的 LLM 跑完整流程，不需要 API key。
