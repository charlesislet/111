"""用假的 LLM 測整條流程，不需要 API key：pytest -q"""
import re

from kb_extract import ExtractConfig, Extractor, MarkdownParser, MinerUParser, TreeBuilder, tree_outline
from kb_extract.models import (ChapterPoints, ExtractionResult, KeyPoint, NodeSummary, VerifyVerdict)
from kb_extract.parsing import html_table_to_markdown
from kb_extract.verify import CitationVerifier, lexical_support

DOC = """# 2026 年度營運報告
<!-- page: 1 -->
本報告說明公司 2026 年的營運成果與明年規劃。
## 營收表現
<!-- page: 2 -->
全年營收達新台幣 52 億元，較去年成長 18%，主要來自雲端訂閱業務。
雲端訂閱營收占比由 35% 提升到 48%。
<!-- page: 3 -->
| 季度 | 營收（億） |
|---|---|
| Q1 | 11 |
| Q4 | 15 |
## 成本與人力
<!-- page: 4 -->
### 人力
全年新增 120 名工程師，研發人力占比達 40%。
### 雲端成本
<!-- page: 5 -->
導入自動擴縮容後，雲端基礎設施成本下降 22%。
## 2027 規劃
<!-- page: 6 -->
明年將拓展日本與東南亞市場，目標海外營收占比 25%。
"""


class FakeLLM:
    """依 schema 回傳固定內容；從 prompt 讀出頁碼，模擬會正確引用的模型。"""

    def __init__(self, hallucinate_page: int | None = None):
        self.calls: list[str] = []
        self.hallucinate_page = hallucinate_page

    def generate_json(self, system, user, schema, *, max_tokens=4096):
        self.calls.append(schema.__name__)
        pages = [int(p) for p in re.findall(r"\[p\.(\d+)\]", user)] or [1]
        if schema is NodeSummary:
            return NodeSummary(summary="摘要：" + user[-40:].replace("\n", " "))
        if schema is ChapterPoints:
            if "雲端訂閱" in user:
                return ChapterPoints(key_points=[KeyPoint(point="全年營收達新台幣 52 億元，較去年成長 18%",
                                                          importance="high", source_pages=[2])])
            if "自動擴縮容" in user:
                return ChapterPoints(key_points=[KeyPoint(point="導入自動擴縮容後，雲端基礎設施成本下降 22%",
                                                          importance="medium", source_pages=[5])])
            return ChapterPoints(key_points=[])
        if schema is ExtractionResult:
            pts = [KeyPoint(point="全年營收達新台幣 52 億元，較去年成長 18%", importance="high", source_pages=[2]),
                   KeyPoint(point="雲端基礎設施成本下降 22%", importance="medium", source_pages=[5])]
            if self.hallucinate_page:
                pts.append(KeyPoint(point="公司將於 2027 年上市", importance="high",
                                    source_pages=[self.hallucinate_page]))
            return ExtractionResult(summary="營收成長且成本下降。", key_points=pts, keywords=["營收"],
                                    entities={"orgs": ["公司"]}, suggested_questions=["成長來源？"])
        if schema is VerifyVerdict:
            return VerifyVerdict(supported=False, reason="原文沒有提到上市")
        raise AssertionError(schema)


def parse():
    return MarkdownParser.parse_text(DOC, "report", "2026 年度營運報告")


def test_markdown_parser_pages_and_headings():
    doc = parse()
    assert doc.num_pages == 6
    heads = [(b.level, b.text) for b in doc.blocks if b.type.value == "heading"]
    assert heads[0] == (1, "2026 年度營運報告")
    assert (3, "雲端成本") in heads
    table = next(b for b in doc.blocks if b.type.value == "table")
    assert table.page == 3


def test_tree_structure():
    doc = parse()
    root = TreeBuilder(FakeLLM()).build_structure(doc)
    report = root.children[0]
    titles = [c.title for c in report.children]
    assert titles == ["2026 年度營運報告（導言）", "營收表現", "成本與人力", "2027 規劃"]
    cost = report.children[2]
    assert [c.title for c in cost.children] == ["人力", "雲端成本"]
    assert (cost.page_start, cost.page_end) == (4, 5)
    # 原文只存在葉節點
    assert all(not n.block_ids for n in root.walk() if not n.is_leaf)


def test_large_leaf_is_split():
    md = "# 長章節\n" + "\n".join(f"<!-- page: {i} -->\n" + "內容" * 300 + "\n" for i in range(1, 6))
    doc = MarkdownParser.parse_text(md, "long", "長文件")
    from kb_extract.tree import TreeConfig
    root = TreeBuilder(FakeLLM(), TreeConfig(leaf_max_tokens=1300)).build_structure(doc)
    leaves = [n for n in root.walk() if n.is_leaf]
    assert len(leaves) >= 3
    assert all("頁" in n.title for n in leaves)


def test_single_pass_strategy():
    llm = FakeLLM()
    out = Extractor(llm, llm).run(parse())
    assert out.strategy == "single_pass"
    assert all(p.verified for p in out.result.key_points)


def test_tree_strategy_and_verification():
    llm = FakeLLM(hallucinate_page=6)
    cfg = ExtractConfig(single_pass_tokens=10)          # 強制走長文件路徑
    out = Extractor(llm, llm, cfg).run(parse())
    assert out.strategy == "tree"
    assert out.tree is not None and "營收表現" in tree_outline(out.tree)
    assert "ChapterPoints" in llm.calls and "NodeSummary" in llm.calls
    # p.6 不在候選頁碼中，reduce 後被清掉 → 驗證判定不通過
    bad = next(p for p in out.result.key_points if "上市" in p.point)
    assert bad.verified is False
    good = next(p for p in out.result.key_points if "52 億" in p.point)
    assert good.verified is True


def test_drop_unverified():
    llm = FakeLLM(hallucinate_page=6)
    out = Extractor(llm, llm, ExtractConfig(drop_unverified=True)).run(parse())
    assert all(p.verified for p in out.result.key_points)
    assert not any("上市" in p.point for p in out.result.key_points)


def test_llm_judge_used_when_lexical_low():
    doc = parse()
    llm = FakeLLM()
    kp = KeyPoint(point="公司將於 2027 年上市", importance="high", source_pages=[6])
    [res] = CitationVerifier(llm).verify([kp], doc)
    assert res.verified is False and "VerifyVerdict" in llm.calls


def test_lexical_support():
    assert lexical_support("營收成長 18%", "全年營收較去年成長 18%") > 0.6
    assert lexical_support("公司將上市", "營收成長") < 0.3


def test_mineru_content_list_and_tables():
    items = [
        {"type": "text", "text": "第一章 概述", "text_level": 1, "page_idx": 0},
        {"type": "text", "text": "內文", "page_idx": 0},
        {"type": "table", "table_body": "<table><tr><th>A</th><th>B</th></tr><tr><td>1</td><td>2</td></tr></table>",
         "table_caption": ["表 1"], "page_idx": 1},
        {"type": "image", "img_caption": [], "page_idx": 1},
    ]
    doc = MinerUParser.from_content_list(items, "d", "t")
    assert doc.num_pages == 2 and len(doc.blocks) == 3
    assert doc.blocks[2].text == "表 1\n| A | B |\n|---|---|\n| 1 | 2 |"
    assert html_table_to_markdown("") == ""
