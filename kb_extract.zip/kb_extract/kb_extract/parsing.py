"""文件解析：把 PDF / Office 檔轉成帶頁碼與標題層級的 Block 清單。

解析器可替換，萃取流程只吃 ParsedDocument：
- MinerUParser：建議中文文件優先使用（MinerU2.5-Pro，支援跨頁表格合併、PPTX/XLSX）
- DoclingParser：英文為主的文件
- MarkdownParser：已經是 Markdown 的內容，或測試用
"""
from __future__ import annotations

import glob
import json
import os
import re
import subprocess
import tempfile
from html.parser import HTMLParser
from pathlib import Path
from typing import Protocol

from .models import Block, BlockType, ParsedDocument


class Parser(Protocol):
    def parse(self, path: str, doc_id: str) -> ParsedDocument: ...


# ---------- MinerU ----------

class _HTMLTableToMarkdown(HTMLParser):
    """MinerU 的表格是 HTML，轉成 Markdown 表格較省 token、LLM 也較好讀。"""

    def __init__(self):
        super().__init__()
        self.rows: list[list[str]] = []
        self._cell: list[str] | None = None

    def handle_starttag(self, tag, attrs):
        if tag == "tr":
            self.rows.append([])
        elif tag in ("td", "th"):
            self._cell = []

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self._cell is not None and self.rows:
            self.rows[-1].append(" ".join("".join(self._cell).split()))
            self._cell = None

    def handle_data(self, data):
        if self._cell is not None:
            self._cell.append(data)


def html_table_to_markdown(html: str) -> str:
    p = _HTMLTableToMarkdown()
    p.feed(html)
    rows = [r for r in p.rows if r]
    if not rows:
        return ""
    width = max(len(r) for r in rows)
    rows = [r + [""] * (width - len(r)) for r in rows]
    lines = ["| " + " | ".join(rows[0]) + " |", "|" + "---|" * width]
    lines += ["| " + " | ".join(r) + " |" for r in rows[1:]]
    return "\n".join(lines)


class MinerUParser:
    """呼叫 MinerU CLI（pip install "mineru[core]"），讀取輸出的 *_content_list.json。

    content_list 每個項目大致為：
      {"type": "text"|"table"|"image"|"equation", "text": ..., "text_level": 1,
       "page_idx": 0, "table_body": "<table>...", "img_caption": [...], "table_caption": [...]}
    不同版本欄位可能略有差異，升級 MinerU 後請用一份樣本確認。
    """

    def __init__(self, backend: str = "vlm-transformers", extra_args: list[str] | None = None):
        self.backend = backend
        self.extra_args = extra_args or []

    def parse(self, path: str, doc_id: str) -> ParsedDocument:
        with tempfile.TemporaryDirectory() as out:
            subprocess.run(["mineru", "-p", path, "-o", out, "-b", self.backend, *self.extra_args],
                           check=True, capture_output=True)
            found = glob.glob(os.path.join(out, "**", "*_content_list.json"), recursive=True)
            if not found:
                raise RuntimeError("MinerU 沒有產生 content_list.json")
            items = json.loads(Path(found[0]).read_text(encoding="utf-8"))
        return self.from_content_list(items, doc_id, title=Path(path).stem)

    @staticmethod
    def from_content_list(items: list[dict], doc_id: str, title: str) -> ParsedDocument:
        blocks: list[Block] = []
        max_page = 1
        for i, it in enumerate(items):
            page = int(it.get("page_idx", 0)) + 1
            max_page = max(max_page, page)
            kind = it.get("type")
            if kind == "text":
                text = (it.get("text") or "").strip()
                if not text:
                    continue
                level = int(it.get("text_level") or 0)
                btype = BlockType.HEADING if level else BlockType.TEXT
            elif kind == "table":
                caption = " ".join(it.get("table_caption") or [])
                text = "\n".join(x for x in [caption, html_table_to_markdown(it.get("table_body") or "")] if x)
                level, btype = 0, BlockType.TABLE
            elif kind == "image":
                caption = " ".join(it.get("img_caption") or [])
                if not caption:
                    continue        # 沒有說明文字的圖片對摘要沒幫助；需要時可另外用 VLM 產生描述
                text, level, btype = f"［圖］{caption}", 0, BlockType.IMAGE
            elif kind == "equation":
                text, level, btype = it.get("text") or "", 0, BlockType.TEXT
            else:
                continue
            blocks.append(Block(id=f"b{i}", page=page, type=btype, text=text, level=level))
        return ParsedDocument(doc_id=doc_id, title=title, num_pages=max_page, blocks=blocks)


# ---------- Docling ----------

class DoclingParser:
    """pip install docling。中文支援較弱，適合英文文件。"""

    def parse(self, path: str, doc_id: str) -> ParsedDocument:
        from docling.document_converter import DocumentConverter

        doc = DocumentConverter().convert(path).document
        blocks: list[Block] = []
        max_page = 1
        for i, (item, depth) in enumerate(doc.iterate_items()):
            page = item.prov[0].page_no if getattr(item, "prov", None) else 1
            max_page = max(max_page, page)
            label = str(getattr(item, "label", "")).lower()
            if "table" in label:
                text, btype, level = item.export_to_markdown(doc=doc), BlockType.TABLE, 0
            elif "title" in label or "section_header" in label:
                text, btype = item.text, BlockType.HEADING
                level = 1 if "title" in label else int(getattr(item, "level", 1)) + 1
            elif hasattr(item, "text") and item.text:
                text, btype, level = item.text, BlockType.TEXT, 0
            else:
                continue
            blocks.append(Block(id=f"b{i}", page=page, type=btype, text=text.strip(), level=level))
        return ParsedDocument(doc_id=doc_id, title=Path(path).stem, num_pages=max_page, blocks=blocks)


# ---------- Markdown ----------

_PAGE_MARK = re.compile(r"<!--\s*page:\s*(\d+)\s*-->")
_HEADING = re.compile(r"^(#{1,6})\s+(.*)$")


class MarkdownParser:
    """讀 Markdown；用 `<!-- page: N -->` 標記換頁（沒有標記時全部視為第 1 頁）。"""

    def parse(self, path: str, doc_id: str) -> ParsedDocument:
        return self.parse_text(Path(path).read_text(encoding="utf-8"), doc_id, Path(path).stem)

    @staticmethod
    def parse_text(md: str, doc_id: str, title: str) -> ParsedDocument:
        blocks: list[Block] = []
        page, buf, n = 1, [], 0

        def flush():
            nonlocal buf, n
            text = "\n".join(buf).strip()
            if text:
                btype = BlockType.TABLE if text.startswith("|") else BlockType.TEXT
                blocks.append(Block(id=f"b{n}", page=page, type=btype, text=text))
                n += 1
            buf = []

        for line in md.splitlines():
            if m := _PAGE_MARK.search(line):
                flush()
                page = int(m.group(1))
            elif m := _HEADING.match(line):
                flush()
                blocks.append(Block(id=f"b{n}", page=page, type=BlockType.HEADING,
                                    text=m.group(2).strip(), level=len(m.group(1))))
                n += 1
            elif not line.strip():
                flush()
            else:
                buf.append(line)
        flush()
        return ParsedDocument(doc_id=doc_id, title=title, num_pages=page, blocks=blocks)
