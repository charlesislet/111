"""所有 prompt 集中管理，方便迭代與做 A/B 評測。"""

SYSTEM = (
    "你是企業知識庫的文件分析助理。只根據提供的原文作答，不可加入原文沒有的資訊。"
    "所有輸出使用繁體中文（台灣用語）。每個重點都必須標註支持它的原文頁碼，"
    "頁碼只能使用原文中 [p.N] 標記出現過的數字。"
)

AUDIENCE_DEFAULT = "沒有讀過這份文件、需要快速掌握內容的公司同仁"

LEAF_SUMMARY = """以下是文件〈{doc_title}〉中「{node_title}」這一節的原文（第 {page_start}–{page_end} 頁）。
請用 2 到 4 句摘要這一節的核心內容，保留關鍵數字、結論與決策。

<原文>
{text}
</原文>"""

PARENT_SUMMARY = """以下是文件〈{doc_title}〉中「{node_title}」底下各小節的摘要。
請整合成 2 到 4 句，說明這一部分整體在講什麼、最重要的結論是什麼。

<小節摘要>
{children}
</小節摘要>"""

CHAPTER_POINTS = """讀者：{audience}

以下是文件〈{doc_title}〉中「{node_title}」的原文（第 {page_start}–{page_end} 頁），每段前有 [p.N] 頁碼標記。
請列出這一節最多 {max_points} 個重點，依重要性排序。每個重點一句話，並附上 source_pages。
若這一節沒有實質內容（例如目錄、附錄索引），回傳空陣列。

<原文>
{text}
</原文>"""

SINGLE_PASS = """讀者：{audience}

以下是文件〈{doc_title}〉的完整原文，每段前有 [p.N] 頁碼標記。
請產出：
- summary：三到五句整體摘要
- key_points：最多 {max_points} 個重點，依重要性排序，每點附 source_pages
- keywords：5 到 10 個關鍵字
- entities：出現的人名、組織、日期
- suggested_questions：讀者可能會問的 3 到 5 個問題

<原文>
{text}
</原文>"""

REDUCE = """讀者：{audience}

以下是文件〈{doc_title}〉的目錄樹摘要，以及各章節已萃取出的候選重點（含頁碼）。
請產出整份文件的結果：
- summary：三到五句整體摘要，依據目錄樹摘要撰寫
- key_points：從候選重點中挑選並合併成最多 {max_points} 個，依重要性排序。
  合併時保留原本的 source_pages，不可新增候選重點中沒有的頁碼或內容。
- keywords、entities、suggested_questions

<目錄樹摘要>
{tree_outline}
</目錄樹摘要>

<候選重點>
{candidates}
</候選重點>"""

VERIFY = """請判斷「重點」是否能由「原文」直接支持。
只要重點的主要主張在原文中有明確依據就算支持；若重點包含原文沒有的數字、結論或推論，判定為不支持。

<重點>
{point}
</重點>

<原文>
{evidence}
</原文>"""
