"""命令列：python -m kb_extract.cli 檔案.pdf -o result.json

環境變數：
  KB_PROVIDER      anthropic | openai（預設 anthropic；openai 也用於 vLLM / Ollama）
  KB_FAST_MODEL    逐節摘要、map、驗證用的小模型
  KB_STRONG_MODEL  單次萃取與 reduce 用的強模型
  KB_BASE_URL      OpenAI 相容端點（地端模型），例如 http://localhost:8000/v1
  ANTHROPIC_API_KEY / OPENAI_API_KEY
"""
from __future__ import annotations

import argparse
import logging
import os
from pathlib import Path

from .extract import ExtractConfig, Extractor
from .llm import AnthropicClient, OpenAICompatibleClient
from .parsing import DoclingParser, MarkdownParser, MinerUParser

PARSERS = {"mineru": MinerUParser, "docling": DoclingParser, "markdown": MarkdownParser}


def make_llm(model: str):
    provider = os.getenv("KB_PROVIDER", "anthropic")
    if provider == "anthropic":
        return AnthropicClient(model)
    return OpenAICompatibleClient(model, base_url=os.getenv("KB_BASE_URL"),
                                  strict_schema=os.getenv("KB_STRICT_SCHEMA", "1") == "1")


def main(argv: list[str] | None = None) -> None:
    ap = argparse.ArgumentParser(description="從文件萃取結構化重點")
    ap.add_argument("path")
    ap.add_argument("-o", "--output", default=None, help="輸出 JSON 路徑（預設印到螢幕）")
    ap.add_argument("--parser", choices=PARSERS, default=None,
                    help="預設：.md 用 markdown，其餘用 mineru")
    ap.add_argument("--audience", default=None, help="目標讀者，例如「業務主管」")
    ap.add_argument("--max-points", type=int, default=10)
    ap.add_argument("--drop-unverified", action="store_true")
    args = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    parser_name = args.parser or ("markdown" if args.path.endswith(".md") else "mineru")
    doc = PARSERS[parser_name]().parse(args.path, doc_id=Path(args.path).stem)

    cfg = ExtractConfig(max_points=args.max_points, drop_unverified=args.drop_unverified)
    if args.audience:
        cfg.audience = args.audience
    fast = make_llm(os.getenv("KB_FAST_MODEL", "claude-haiku-5-5"))
    strong = make_llm(os.getenv("KB_STRONG_MODEL", "claude-sonnet-5-5"))
    insights = Extractor(fast, strong, cfg).run(doc)

    out = insights.model_dump_json(indent=2)
    if args.output:
        Path(args.output).write_text(out, encoding="utf-8")
    else:
        print(out)


if __name__ == "__main__":
    main()
