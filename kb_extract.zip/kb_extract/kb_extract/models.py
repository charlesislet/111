"""資料模型：解析結果、目錄樹、萃取結果。"""
from __future__ import annotations

from enum import Enum
from typing import Literal

from pydantic import BaseModel, Field


# ---------- 解析結果 ----------

class BlockType(str, Enum):
    HEADING = "heading"
    TEXT = "text"
    TABLE = "table"
    IMAGE = "image"      # 圖片或圖表；text 放解析器或 VLM 產生的描述
    LIST = "list"


class Block(BaseModel):
    """解析器輸出的最小單位：一段文字、一個表格或一張圖。"""
    id: str
    page: int                      # 1-based 頁碼
    type: BlockType
    text: str                      # 表格為 Markdown 表格，圖片為描述文字
    level: int = 0                 # 標題層級，1 = 最上層；非標題為 0


class ParsedDocument(BaseModel):
    doc_id: str
    title: str
    num_pages: int
    blocks: list[Block]


# ---------- 目錄樹 ----------

class TreeNode(BaseModel):
    """樹狀目錄索引的節點。葉節點持有原文 block，非葉節點只有子節點摘要。"""
    node_id: str
    title: str
    level: int                     # 0 = 根節點
    page_start: int
    page_end: int
    summary: str = ""
    block_ids: list[str] = Field(default_factory=list)   # 只有葉節點有
    children: list["TreeNode"] = Field(default_factory=list)

    @property
    def is_leaf(self) -> bool:
        return not self.children

    def walk(self):
        yield self
        for c in self.children:
            yield from c.walk()


# ---------- 萃取結果（LLM 結構化輸出） ----------

class KeyPoint(BaseModel):
    point: str = Field(description="一句話說明的重點，繁體中文")
    importance: Literal["high", "medium", "low"]
    source_pages: list[int] = Field(description="支持這個重點的原文頁碼")
    # 以下由程式填入，不要求 LLM 輸出
    verified: bool | None = None
    verify_note: str | None = None


class Entities(BaseModel):
    people: list[str] = Field(default_factory=list)
    orgs: list[str] = Field(default_factory=list)
    dates: list[str] = Field(default_factory=list)


class ExtractionResult(BaseModel):
    summary: str = Field(description="三到五句的整體摘要")
    key_points: list[KeyPoint]
    keywords: list[str]
    entities: Entities
    suggested_questions: list[str] = Field(description="讀者可能會問的問題，3 到 5 個")


class ChapterPoints(BaseModel):
    """map 階段：單一章節的重點。"""
    key_points: list[KeyPoint]


class NodeSummary(BaseModel):
    summary: str = Field(description="此節點內容的摘要，繁體中文，2 到 4 句")


class VerifyVerdict(BaseModel):
    supported: bool = Field(description="原文是否支持這個重點")
    reason: str = Field(description="一句話說明判斷理由")


class DocumentInsights(BaseModel):
    """最終存進資料庫、給前端與簡報大綱使用的完整結果。"""
    doc_id: str
    strategy: Literal["single_pass", "tree"]
    result: ExtractionResult
    tree: TreeNode | None = None
