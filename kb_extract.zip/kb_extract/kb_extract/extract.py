"""重點萃取主流程。

依文件長度自動選策略：
- 短文件（≤ single_pass_tokens）：整份交給強模型，一次產出
- 長文件：建樹狀目錄索引 → 每個葉節點各自萃取候選重點（map，小模型）
         → 依目錄樹摘要與候選重點合併成最終結果（reduce，強模型）
最後一律做出處驗證。

對應 2026 研究發現的設計：
- 幻覺集中在長輸出後段 → 每次呼叫只輸出少量重點（map 每節 ≤ 5、最終 ≤ 10）
- 摘要長度不隨原文成長 → 長文件不整份丟，一律先分節
"""
from __future__ import annotations

import logging
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field

from . import prompts
from .llm import LLMClient
from .models import (ChapterPoints, DocumentInsights, ExtractionResult, KeyPoint, ParsedDocument,
                     TreeNode)
from .tree import TreeBuilder, TreeConfig, estimate_tokens, render_blocks, tree_outline
from .verify import CitationVerifier, VerifyConfig

log = logging.getLogger(__name__)

_RANK = {"high": 0, "medium": 1, "low": 2}


@dataclass
class ExtractConfig:
    audience: str = prompts.AUDIENCE_DEFAULT
    single_pass_tokens: int = 30_000
    max_points: int = 10
    points_per_leaf: int = 5
    max_candidates: int = 60          # 送進 reduce 的候選重點上限
    drop_unverified: bool = False     # True：直接移除未通過驗證的重點；False：保留但標記
    workers: int = 8
    tree: TreeConfig = field(default_factory=TreeConfig)
    verify: VerifyConfig = field(default_factory=VerifyConfig)


class Extractor:
    """fast_llm：逐節摘要、map、驗證；strong_llm：單次萃取與 reduce。可傳同一個。"""

    def __init__(self, fast_llm: LLMClient, strong_llm: LLMClient, config: ExtractConfig | None = None):
        self.fast = fast_llm
        self.strong = strong_llm
        self.cfg = config or ExtractConfig()

    def run(self, doc: ParsedDocument) -> DocumentInsights:
        full_text = render_blocks(doc.blocks)
        if estimate_tokens(full_text) <= self.cfg.single_pass_tokens:
            log.info("doc=%s strategy=single_pass", doc.doc_id)
            result, tree, strategy = self._single_pass(doc, full_text), None, "single_pass"
        else:
            log.info("doc=%s strategy=tree", doc.doc_id)
            tree = TreeBuilder(self.fast, self.cfg.tree).build(doc)
            result, strategy = self._tree_map_reduce(doc, tree), "tree"

        verifier = CitationVerifier(self.fast, self.cfg.verify)
        points = verifier.verify(result.key_points, doc)
        if self.cfg.drop_unverified:
            dropped = [p for p in points if not p.verified]
            if dropped:
                log.warning("doc=%s 移除 %d 個未通過驗證的重點", doc.doc_id, len(dropped))
            points = [p for p in points if p.verified]
        result.key_points = points
        return DocumentInsights(doc_id=doc.doc_id, strategy=strategy, result=result, tree=tree)

    # ---------- 短文件 ----------

    def _single_pass(self, doc: ParsedDocument, text: str) -> ExtractionResult:
        prompt = prompts.SINGLE_PASS.format(audience=self.cfg.audience, doc_title=doc.title,
                                            max_points=self.cfg.max_points, text=text)
        return self.strong.generate_json(prompts.SYSTEM, prompt, ExtractionResult)

    # ---------- 長文件 ----------

    def _tree_map_reduce(self, doc: ParsedDocument, tree: TreeNode) -> ExtractionResult:
        by_id = {b.id: b for b in doc.blocks}
        leaves = [n for n in tree.walk() if n.is_leaf and n.block_ids]

        # 相鄰的小葉節點合併成一批再萃取：避免短章節被漏掉，也減少呼叫次數
        batches: list[list[TreeNode]] = []
        cur, cur_tok = [], 0
        for leaf in leaves:
            t = estimate_tokens(render_blocks([by_id[i] for i in leaf.block_ids]))
            if cur and cur_tok + t > self.cfg.tree.leaf_max_tokens:
                batches.append(cur)
                cur, cur_tok = [], 0
            cur.append(leaf)
            cur_tok += t
        if cur:
            batches.append(cur)

        def map_batch(nodes: list[TreeNode]) -> list[KeyPoint]:
            text = "\n\n".join(f"## {n.title}\n" + render_blocks([by_id[i] for i in n.block_ids]) for n in nodes)
            valid_pages = {by_id[i].page for n in nodes for i in n.block_ids}
            title = nodes[0].title if len(nodes) == 1 else f"{nodes[0].title} 至 {nodes[-1].title}"
            prompt = prompts.CHAPTER_POINTS.format(
                audience=self.cfg.audience, doc_title=doc.title, node_title=title,
                page_start=min(valid_pages), page_end=max(valid_pages),
                max_points=self.cfg.points_per_leaf, text=text)
            pts = self.fast.generate_json(prompts.SYSTEM, prompt, ChapterPoints, max_tokens=1500).key_points
            # 頁碼必須是這批原文實際出現的頁，否則代表模型亂標
            return [p for p in pts if p.source_pages and all(q in valid_pages for q in p.source_pages)]

        with ThreadPoolExecutor(self.cfg.workers) as pool:
            candidates = [p for pts in pool.map(map_batch, batches) for p in pts]

        # 候選太多時，優先保留重要性高的；同重要性依文件順序
        candidates = sorted(enumerate(candidates), key=lambda x: (_RANK[x[1].importance], x[0]))
        candidates = [p for _, p in candidates[: self.cfg.max_candidates]]
        cand_text = "\n".join(f"- [{p.importance}] {p.point}（p.{','.join(map(str, p.source_pages))}）"
                              for p in candidates)

        prompt = prompts.REDUCE.format(audience=self.cfg.audience, doc_title=doc.title,
                                       max_points=self.cfg.max_points,
                                       tree_outline=tree_outline(tree), candidates=cand_text)
        result = self.strong.generate_json(prompts.SYSTEM, prompt, ExtractionResult)

        # reduce 階段不應出現候選以外的頁碼
        allowed = {q for p in candidates for q in p.source_pages}
        for p in result.key_points:
            p.source_pages = [q for q in p.source_pages if q in allowed]
        return result
