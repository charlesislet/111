"""出處驗證：確認每個重點真的能由它標註的頁碼支持。

兩段式，先便宜後昂貴：
1. 字元二元組重疊率夠高 → 直接通過，不呼叫 LLM
2. 否則交給小模型判斷（LLM-as-judge）
頁碼不存在或該頁沒有內容 → 直接判定不通過。
"""
from __future__ import annotations

import re
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

from . import prompts
from .llm import LLMClient
from .models import Block, KeyPoint, ParsedDocument, VerifyVerdict

_STRIP = re.compile(r"[\s\W_]+", re.UNICODE)


def _bigrams(text: str) -> set[str]:
    t = _STRIP.sub("", text.lower())
    return {t[i : i + 2] for i in range(len(t) - 1)}


def lexical_support(point: str, evidence: str) -> float:
    """重點的字元二元組有多少比例出現在原文中（對中文比斷詞穩定）。"""
    p = _bigrams(point)
    return len(p & _bigrams(evidence)) / len(p) if p else 0.0


@dataclass
class VerifyConfig:
    lexical_pass: float = 0.6        # 重疊率達此值直接通過
    page_window: int = 0             # 也納入前後幾頁（重點跨頁時有用）
    max_evidence_tokens: int = 6000
    workers: int = 8


class CitationVerifier:
    def __init__(self, llm: LLMClient | None, config: VerifyConfig | None = None):
        self.llm = llm                # None = 只做字面比對
        self.cfg = config or VerifyConfig()

    def verify(self, points: list[KeyPoint], doc: ParsedDocument) -> list[KeyPoint]:
        pages: dict[int, list[Block]] = {}
        for b in doc.blocks:
            pages.setdefault(b.page, []).append(b)
        with ThreadPoolExecutor(self.cfg.workers) as pool:
            return list(pool.map(lambda p: self._verify_one(p, pages, doc.num_pages), points))

    def _evidence(self, kp: KeyPoint, pages: dict[int, list[Block]]) -> str:
        wanted = sorted({q for p in kp.source_pages
                         for q in range(p - self.cfg.page_window, p + self.cfg.page_window + 1)})
        text = "\n".join(f"[p.{p}] " + "\n".join(b.text for b in pages.get(p, [])) for p in wanted if p in pages)
        return text[: self.cfg.max_evidence_tokens * 2]

    def _verify_one(self, kp: KeyPoint, pages: dict[int, list[Block]], num_pages: int) -> KeyPoint:
        kp = kp.model_copy()
        bad = [p for p in kp.source_pages if p < 1 or p > num_pages or p not in pages]
        if not kp.source_pages or len(bad) == len(kp.source_pages):
            kp.verified, kp.verify_note = False, f"頁碼不存在或無內容：{kp.source_pages}"
            return kp
        evidence = self._evidence(kp, pages)
        score = lexical_support(kp.point, evidence)
        if score >= self.cfg.lexical_pass:
            kp.verified, kp.verify_note = True, f"字面比對通過（{score:.2f}）"
            return kp
        if self.llm is None:
            kp.verified, kp.verify_note = False, f"字面重疊不足（{score:.2f}），未啟用 LLM 驗證"
            return kp
        v = self.llm.generate_json(prompts.SYSTEM, prompts.VERIFY.format(point=kp.point, evidence=evidence),
                                   VerifyVerdict, max_tokens=300)
        kp.verified, kp.verify_note = v.supported, v.reason
        return kp
