"""樹狀目錄索引：依標題建樹 → 切分過大的葉節點 → 由下往上產生摘要。

做法參考 PageIndex 與 VLDB 2026〈Indexing Long Documents for LLM-Based Analysis〉：
文件讀一次，編成「根＝全文摘要、中層＝章節摘要、葉＝原文段落＋頁碼」的樹，
上層摘要直接當文件重點，章節分支可直接當簡報章節，葉節點供問答檢索與引用。
"""
from __future__ import annotations

import re
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass

from . import prompts
from .llm import LLMClient
from .models import Block, BlockType, NodeSummary, ParsedDocument, TreeNode

_CJK = re.compile(r"[㐀-鿿豈-﫿　-〿＀-￯]")


def estimate_tokens(text: str) -> int:
    """粗估 token 數：中日韓字元約 1 字 1 token，其他約 4 字元 1 token（偏保守）。"""
    cjk = len(_CJK.findall(text))
    return cjk + (len(text) - cjk) // 4 + 1


def render_blocks(blocks: list[Block]) -> str:
    """把 block 轉成給 LLM 的文字，每換一頁加一個 [p.N] 標記。"""
    out, last_page = [], None
    for b in blocks:
        prefix = ""
        if b.page != last_page:
            prefix = f"[p.{b.page}] "
            last_page = b.page
        text = ("#" * b.level + " " + b.text) if b.type == BlockType.HEADING else b.text
        out.append(prefix + text)
    return "\n".join(out)


@dataclass
class TreeConfig:
    max_depth: int = 3              # 更深的標題當一般文字處理，避免樹太碎
    leaf_max_tokens: int = 6000     # 葉節點超過就依段落切分
    min_leaf_tokens: int = 80       # 太短的葉節點（只有標題）不送 LLM 摘要
    workers: int = 8                # 平行呼叫 LLM 的數量


class TreeBuilder:
    def __init__(self, llm: LLMClient, config: TreeConfig | None = None):
        self.llm = llm
        self.cfg = config or TreeConfig()

    # ---------- 1. 建結構（不呼叫 LLM） ----------

    def build_structure(self, doc: ParsedDocument) -> TreeNode:
        self._counter = 0
        root = TreeNode(node_id="root", title=doc.title, level=0, page_start=1, page_end=doc.num_pages)
        stack = [root]
        for b in doc.blocks:
            if b.type == BlockType.HEADING and 1 <= b.level <= self.cfg.max_depth:
                while stack[-1].level >= b.level:
                    stack.pop()
                node = TreeNode(node_id=self._next_id(), title=b.text, level=b.level,
                                page_start=b.page, page_end=b.page, block_ids=[b.id])
                stack[-1].children.append(node)
                stack.append(node)
            else:
                stack[-1].block_ids.append(b.id)

        by_id = {b.id: b for b in doc.blocks}
        self._normalize(root, by_id)
        self._split_large_leaves(root, by_id)
        self._fix_pages(root, by_id)
        return root

    def _next_id(self) -> str:
        self._counter += 1
        return f"n{self._counter}"

    def _normalize(self, node: TreeNode, by_id: dict[str, Block]) -> None:
        """非葉節點自己的段落（章節開頭的導言）移到第一個子節點，確保原文只存在葉節點。"""
        for c in node.children:
            self._normalize(c, by_id)
        if node.children:
            own = [i for i in node.block_ids if by_id[i].type != BlockType.HEADING]
            if own:
                intro = TreeNode(node_id=self._next_id(), title=f"{node.title}（導言）", level=node.level + 1,
                                 page_start=by_id[own[0]].page, page_end=by_id[own[-1]].page, block_ids=own)
                node.children.insert(0, intro)
            node.block_ids = []

    def _split_large_leaves(self, node: TreeNode, by_id: dict[str, Block]) -> None:
        for c in node.children:
            self._split_large_leaves(c, by_id)
        if node.children or not node.block_ids:
            return
        chunks, cur, cur_tok = [], [], 0
        for bid in node.block_ids:
            t = estimate_tokens(by_id[bid].text)
            if cur and cur_tok + t > self.cfg.leaf_max_tokens:
                chunks.append(cur)
                cur, cur_tok = [], 0
            cur.append(bid)
            cur_tok += t
        if cur:
            chunks.append(cur)
        if len(chunks) <= 1:
            return
        for part in chunks:
            p0, p1 = by_id[part[0]].page, by_id[part[-1]].page
            label = f"第 {p0} 頁" if p0 == p1 else f"第 {p0}–{p1} 頁"
            node.children.append(TreeNode(node_id=self._next_id(), title=f"{node.title}（{label}）",
                                          level=node.level + 1, page_start=p0, page_end=p1, block_ids=part))
        node.block_ids = []

    def _fix_pages(self, node: TreeNode, by_id: dict[str, Block]) -> None:
        for c in node.children:
            self._fix_pages(c, by_id)
        pages = [by_id[i].page for i in node.block_ids] + \
                [p for c in node.children for p in (c.page_start, c.page_end)]
        if pages:
            node.page_start, node.page_end = min(pages), max(pages)

    # ---------- 2. 由下往上摘要 ----------

    def summarize(self, root: TreeNode, doc: ParsedDocument) -> TreeNode:
        by_id = {b.id: b for b in doc.blocks}
        levels: dict[int, list[TreeNode]] = {}
        for n in root.walk():
            levels.setdefault(self._height(n), []).append(n)
        with ThreadPoolExecutor(self.cfg.workers) as pool:
            for h in sorted(levels):                     # 葉節點（高度 0）先做，再往上
                list(pool.map(lambda n: self._summarize_node(n, doc, by_id), levels[h]))
        return root

    def _height(self, n: TreeNode) -> int:
        return 0 if n.is_leaf else 1 + max(self._height(c) for c in n.children)

    def _summarize_node(self, node: TreeNode, doc: ParsedDocument, by_id: dict[str, Block]) -> None:
        if node.is_leaf:
            text = render_blocks([by_id[i] for i in node.block_ids])
            if estimate_tokens(text) < self.cfg.min_leaf_tokens:
                node.summary = text.replace("\n", " ")       # 很短就直接用原文，省一次呼叫
                return
            prompt = prompts.LEAF_SUMMARY.format(doc_title=doc.title, node_title=node.title,
                                                 page_start=node.page_start, page_end=node.page_end, text=text)
        else:
            children = "\n".join(f"- {c.title}（p.{c.page_start}–{c.page_end}）：{c.summary}" for c in node.children)
            prompt = prompts.PARENT_SUMMARY.format(doc_title=doc.title, node_title=node.title, children=children)
        node.summary = self.llm.generate_json(prompts.SYSTEM, prompt, NodeSummary, max_tokens=800).summary

    def build(self, doc: ParsedDocument) -> TreeNode:
        return self.summarize(self.build_structure(doc), doc)


def tree_outline(root: TreeNode, max_level: int = 2) -> str:
    """把樹轉成縮排大綱文字，給 reduce 階段與簡報大綱使用。"""
    lines = []
    for n in root.walk():
        if n.level > max_level:
            continue
        indent = "  " * n.level
        lines.append(f"{indent}- {n.title}（p.{n.page_start}–{n.page_end}）：{n.summary}")
    return "\n".join(lines)
