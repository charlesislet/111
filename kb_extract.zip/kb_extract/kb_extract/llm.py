"""LLM 客戶端抽象層。

萃取流程只依賴 `LLMClient.generate_json()`：給 prompt 與 pydantic 模型，回傳驗證過的物件。
內建兩種實作：
- AnthropicClient：用 tool use 強制結構化輸出
- OpenAICompatibleClient：OpenAI、Azure OpenAI，以及 vLLM、Ollama 等相容端點（地端部署用）
"""
from __future__ import annotations

import json
import re
from typing import Protocol, TypeVar

from pydantic import BaseModel, ValidationError

T = TypeVar("T", bound=BaseModel)


class LLMError(RuntimeError):
    pass


class LLMClient(Protocol):
    def generate_json(self, system: str, user: str, schema: type[T], *, max_tokens: int = 4096) -> T: ...


def _parse_json_loose(text: str) -> dict:
    """容忍 ```json 包裹或前後雜訊的 JSON 解析。"""
    m = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if m:
        text = m.group(1)
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1:
        raise LLMError(f"回應中找不到 JSON：{text[:200]}")
    return json.loads(text[start : end + 1])


def _validate(schema: type[T], data: dict) -> T:
    try:
        return schema.model_validate(data)
    except ValidationError as e:
        raise LLMError(f"輸出不符合 schema：{e}") from e


class AnthropicClient:
    """pip install anthropic"""

    def __init__(self, model: str, api_key: str | None = None, retries: int = 2):
        import anthropic

        self._client = anthropic.Anthropic(api_key=api_key)
        self.model = model
        self.retries = retries

    def generate_json(self, system, user, schema, *, max_tokens=4096):
        tool = {
            "name": "submit",
            "description": "提交結構化結果",
            "input_schema": schema.model_json_schema(),
        }
        last: Exception | None = None
        for _ in range(self.retries + 1):
            resp = self._client.messages.create(
                model=self.model,
                max_tokens=max_tokens,
                system=system,
                messages=[{"role": "user", "content": user}],
                tools=[tool],
                tool_choice={"type": "tool", "name": "submit"},
            )
            for block in resp.content:
                if block.type == "tool_use":
                    try:
                        return _validate(schema, block.input)
                    except LLMError as e:
                        last = e
        raise LLMError(f"重試後仍失敗：{last}")


class OpenAICompatibleClient:
    """pip install openai。base_url 指向 vLLM / Ollama 即可用地端模型。"""

    def __init__(self, model: str, api_key: str | None = None, base_url: str | None = None,
                 strict_schema: bool = True, retries: int = 2):
        from openai import OpenAI

        self._client = OpenAI(api_key=api_key or "not-needed", base_url=base_url)
        self.model = model
        self.strict_schema = strict_schema   # 部分地端伺服器不支援 json_schema，可關閉改用 json_object
        self.retries = retries

    def generate_json(self, system, user, schema, *, max_tokens=4096):
        if self.strict_schema:
            fmt = {"type": "json_schema",
                   "json_schema": {"name": schema.__name__, "schema": schema.model_json_schema()}}
        else:
            fmt = {"type": "json_object"}
            user = f"{user}\n\n請只輸出符合此 JSON Schema 的 JSON：\n{json.dumps(schema.model_json_schema(), ensure_ascii=False)}"
        last: Exception | None = None
        for _ in range(self.retries + 1):
            resp = self._client.chat.completions.create(
                model=self.model,
                max_tokens=max_tokens,
                response_format=fmt,
                messages=[{"role": "system", "content": system}, {"role": "user", "content": user}],
            )
            try:
                return _validate(schema, _parse_json_loose(resp.choices[0].message.content or ""))
            except (LLMError, json.JSONDecodeError) as e:
                last = e
        raise LLMError(f"重試後仍失敗：{last}")
