"""背景任務：使用者上傳後立刻排入佇列，打開文件時重點已經算好。

啟動 worker：
  celery -A kb_extract.tasks worker --loglevel=info --concurrency=4

上傳 API 裡呼叫：
  from kb_extract.tasks import process_document
  process_document.delay(doc_id, stored_path)

`save_insights` 與 `update_status` 請換成你們的資料庫寫入（例如 PostgreSQL 的 JSONB 欄位）。
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from celery import Celery

from .cli import PARSERS, make_llm
from .extract import ExtractConfig, Extractor
from .models import DocumentInsights

app = Celery("kb_extract", broker=os.getenv("CELERY_BROKER_URL", "redis://localhost:6379/0"))
app.conf.task_acks_late = True              # worker 中途掛掉時任務會重新派送
app.conf.worker_prefetch_multiplier = 1     # 長任務不要一次搶太多

OUTPUT_DIR = Path(os.getenv("KB_OUTPUT_DIR", "./insights"))


def update_status(doc_id: str, status: str, detail: str = "") -> None:
    """TODO：寫進 documents 表的 status 欄位，前端據此顯示「處理中／完成／失敗」。"""
    print(json.dumps({"doc_id": doc_id, "status": status, "detail": detail}, ensure_ascii=False))


def save_insights(insights: DocumentInsights) -> None:
    """TODO：改成寫入資料庫。tree 也要存，問答檢索與簡報大綱都會用到。"""
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    (OUTPUT_DIR / f"{insights.doc_id}.json").write_text(insights.model_dump_json(indent=2), encoding="utf-8")


@app.task(bind=True, max_retries=3, default_retry_delay=60)
def process_document(self, doc_id: str, path: str, parser: str = "mineru", audience: str | None = None):
    update_status(doc_id, "parsing")
    try:
        doc = PARSERS[parser]().parse(path, doc_id=doc_id)
        update_status(doc_id, "extracting", f"{doc.num_pages} 頁")
        cfg = ExtractConfig()
        if audience:
            cfg.audience = audience
        fast = make_llm(os.getenv("KB_FAST_MODEL", "claude-haiku-5-5"))
        strong = make_llm(os.getenv("KB_STRONG_MODEL", "claude-sonnet-5-5"))
        insights = Extractor(fast, strong, cfg).run(doc)
        save_insights(insights)
        unverified = sum(1 for p in insights.result.key_points if p.verified is False)
        update_status(doc_id, "done", f"{len(insights.result.key_points)} 個重點，{unverified} 個未通過驗證")
    except Exception as e:  # noqa: BLE001
        update_status(doc_id, "retrying" if self.request.retries < self.max_retries else "failed", str(e))
        raise self.retry(exc=e)
