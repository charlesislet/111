"""The two shapes every step passes along.

A `Document` is what step 1 (ingest) produces and step 2 (gather) reads.
A `Source` is what step 2 produces and steps 3-4 read: a document's text, cut to fit.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Document:
    id: int
    title: str
    content: str  # Markdown text


@dataclass(frozen=True)
class Source:
    """One document handed to the model as grounding."""

    document_id: int
    title: str
    content: str
