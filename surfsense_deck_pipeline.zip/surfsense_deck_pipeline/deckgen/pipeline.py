"""Steps 1-4 in one call: files in, the model's builder script out.

This stops where SurfSense's loop would hand the script to its sandbox
(step 5: run it in a child process with a 120 s limit) and, on failure, show the
error back to the model (step 6). Neither is here; `DraftResult.script` is the
text those steps would take.
"""

from __future__ import annotations

import ast
from dataclasses import dataclass
from pathlib import Path

from deckgen import gather as gathering
from deckgen import generate, ingest, prompt
from deckgen.models import Document, Source


class EmptyScriptError(RuntimeError):
    """The model returned no script."""


@dataclass(frozen=True)
class DraftResult:
    title: str
    script: str
    system_prompt: str
    sources: list[Source]
    # Not a run, only `ast.parse`: None when the text is valid Python syntax.
    syntax_error: str | None


def fallback_title(user_prompt: str | None, sources: list[Source]) -> str:
    """The name when the script gave none: the request, else the sources, else the format."""
    if user_prompt and user_prompt.strip():
        return user_prompt.strip()[:200]
    if not sources:
        return prompt.LABEL
    more = len(sources) - 1
    return sources[0].title + (f" and {more} more" if more else "")


def read_documents(paths: list[str | Path]) -> list[Document]:
    """Step 1."""
    return [ingest.ingest(path, document_id) for document_id, path in enumerate(paths, 1)]


def prepare(
    documents: list[Document], user_prompt: str | None = None, budget_chars: int | None = None
) -> tuple[str, list[Source]]:
    """Steps 2-3: the system prompt and the grounding, ready to send."""
    sources = gathering.gather(
        documents,
        user_prompt,
        budget_chars=budget_chars,
        focus=gathering.DEFAULT_FOCUS,
    )
    return prompt.build(user_prompt), sources


def draft_script(
    paths: list[str | Path],
    llm: generate.LLM,
    user_prompt: str | None = None,
    budget_chars: int | None = None,
) -> DraftResult:
    """Steps 1-4."""
    documents = read_documents(paths)
    system, sources = prepare(documents, user_prompt, budget_chars)
    script = generate.script_reply(generate.run_model(llm, system, sources))
    if not script:
        raise EmptyScriptError("the model returned no script")
    title = generate.script_title(script) or fallback_title(user_prompt, sources)
    try:
        ast.parse(script)
        syntax_error = None
    except SyntaxError as error:
        syntax_error = f"line {error.lineno}: {error.msg}"
    return DraftResult(title, script, system, sources, syntax_error)
