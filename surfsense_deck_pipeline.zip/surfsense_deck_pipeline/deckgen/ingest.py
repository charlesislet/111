"""Step 1 - ingest: turn an uploaded file into Markdown text.

SurfSense parses 50+ formats with LlamaCloud, Unstructured or Docling and then
chunks and indexes the result in a database. This keeps only the part the later
steps need: file in, Markdown text out. Parsers are imported lazily, so a format
you never use needs no package.
"""

from __future__ import annotations

from html.parser import HTMLParser
from pathlib import Path

from deckgen.models import Document

TEXT_SUFFIXES = {".txt", ".md", ".markdown", ".csv", ".tsv", ".json", ".rst", ".log"}


class UnsupportedFormatError(ValueError):
    """No parser for this file type."""


def ingest(path: str | Path, document_id: int) -> Document:
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix in TEXT_SUFFIXES:
        text = path.read_text(encoding="utf-8", errors="replace")
    elif suffix == ".pdf":
        text = _pdf(path)
    elif suffix == ".docx":
        text = _docx(path)
    elif suffix == ".pptx":
        text = _pptx(path)
    elif suffix in {".html", ".htm"}:
        text = _html(path.read_text(encoding="utf-8", errors="replace"))
    else:
        raise UnsupportedFormatError(f"cannot read {path.name}: no parser for '{suffix}'")
    return Document(id=document_id, title=path.stem, content=text.strip())


def _pdf(path: Path) -> str:
    from pypdf import PdfReader

    pages = []
    for number, page in enumerate(PdfReader(str(path)).pages, 1):
        text = (page.extract_text() or "").strip()
        if text:
            pages.append(f"## Page {number}\n\n{text}")
    return "\n\n".join(pages)


def _docx(path: Path) -> str:
    import docx

    lines: list[str] = []
    for paragraph in docx.Document(str(path)).paragraphs:
        text = paragraph.text.strip()
        if not text:
            continue
        style = (paragraph.style.name or "") if paragraph.style is not None else ""
        if style.startswith("Heading") and style[-1:].isdigit():
            lines.append("#" * min(int(style[-1:]), 6) + " " + text)
        else:
            lines.append(text)
    return "\n\n".join(lines)


def _pptx(path: Path) -> str:
    from pptx import Presentation

    blocks = []
    for number, slide in enumerate(Presentation(str(path)).slides, 1):
        title = slide.shapes.title.text_frame.text.strip() if slide.shapes.title is not None else ""
        lines = [f"## Slide {number}: {title}" if title else f"## Slide {number}"]
        for shape in slide.shapes:
            if shape.has_text_frame and shape is not slide.shapes.title:
                lines += [p.text.strip() for p in shape.text_frame.paragraphs if p.text.strip()]
        blocks.append("\n\n".join(lines))
    return "\n\n".join(blocks)


class _TextOnly(HTMLParser):
    SKIP = {"script", "style", "noscript"}
    BLOCK = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "section", "article"}

    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self._skip += 1
        elif tag in self.BLOCK:
            self.parts.append("\n\n")

    def handle_endtag(self, tag):
        if tag in self.SKIP and self._skip:
            self._skip -= 1

    def handle_data(self, data):
        if not self._skip:
            self.parts.append(data)


def _html(markup: str) -> str:
    parser = _TextOnly()
    parser.feed(markup)
    text = "".join(parser.parts)
    return "\n\n".join(line.strip() for line in text.split("\n\n") if line.strip())
