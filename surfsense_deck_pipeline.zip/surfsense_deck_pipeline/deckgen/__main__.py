"""python -m deckgen report.pdf notes.md -p "給主管的 5 分鐘摘要" -o draft_script.py"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from deckgen import generate, pipeline


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="deckgen", description="Steps 1-4: documents -> deck-builder script")
    parser.add_argument("files", nargs="+", help="documents to ground the deck on")
    parser.add_argument("-p", "--prompt", help="what the deck is for (also steers passage selection)")
    parser.add_argument("-o", "--output", default="draft_script.py", help="where to write the script")
    parser.add_argument("--provider", choices=["anthropic", "openai"], default="anthropic")
    parser.add_argument("--model", help="model id (default: DECKGEN_MODEL or claude-sonnet-5-5)")
    parser.add_argument("--base-url", help="OpenAI-compatible endpoint, e.g. http://localhost:11434/v1")
    parser.add_argument("--budget", type=int, help="grounding budget in characters (default 24000)")
    parser.add_argument(
        "--dry-run", action="store_true", help="run steps 1-3 and print the prompt; no model call"
    )
    args = parser.parse_args(argv)

    if args.dry_run:
        documents = pipeline.read_documents(args.files)
        system, sources = pipeline.prepare(documents, args.prompt, args.budget)
        print(system)
        print("=" * 72)
        print(generate.grounding(sources))
        print(f"\n[{len(sources)} source(s), {sum(len(s.content) for s in sources)} chars]", file=sys.stderr)
        return 0

    if args.provider == "anthropic":
        llm: generate.LLM = generate.AnthropicLLM(args.model)
    else:
        if not args.model:
            parser.error("--model is required with --provider openai")
        llm = generate.OpenAICompatibleLLM(args.model, args.base_url)

    result = pipeline.draft_script(args.files, llm, args.prompt, args.budget)
    Path(args.output).write_text(result.script + "\n", encoding="utf-8")
    print(f"title: {result.title}\nwrote: {args.output} ({len(result.script)} chars)")
    if result.syntax_error:
        print(f"warning: not valid Python ({result.syntax_error})", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
