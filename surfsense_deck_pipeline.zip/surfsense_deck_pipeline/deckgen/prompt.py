"""Step 3 - prompt: the system prompt that asks the model to write the builder script.

Same structure as SurfSense's `worker/studio/office/prompt.py`: a contract, the
format's authoring skill, and an optional emphasis taken from the user's request.
The wording here is this project's own; only the structure and the rules it
enforces (facts from the sources only, one standalone script, `# title:` first
line, save to OUTPUT_PATH, standard library + python-pptx, no network, 120 s)
are carried over.
"""

from __future__ import annotations

from string import Template

LABEL = "PowerPoint deck"
LIBRARY = "python-pptx"
SCRIPT_SECONDS = 120

PPTX_SKILL = """\
## Authoring rules for a PowerPoint deck

Build the deck with `python-pptx`, then save it with `prs.save(os.environ["OUTPUT_PATH"])`.
Plan each slide's purpose and one visual system first, then write the whole deck.

- Use 16:9 unless asked otherwise. Set `prs.slide_width` and `prs.slide_height` once.
- Keep one layout language across the deck: the same palette, type scale, spacing and grid.
- Prefer the built-in slide layouts and their placeholders to free text boxes. Fill every
  placeholder you leave visible with final content; no filler copy, no "add image here".
- Keep at least 0.5 in of outer margin and 0.3 in between unrelated regions. Titles and
  subtitles must not overlap anything.
- One purpose per slide. Body text is short phrases, normally at most six bullets.
- Name fonts by family (Arial or Calibri unless asked). Titles 32-40 pt, subtitles 18-24 pt,
  body at least 18 pt. Turn `word_wrap` on for text frames.
- Keep every shape on the slide canvas. Keep picture aspect ratios: give one dimension and
  derive the other.
- Prefer editable native text, shapes, tables and charts. Avoid SmartArt and heavy gradients.
"""

TEMPLATE = Template(
    """\
Write one standalone Python script that builds a $label from the sources below, using their facts only.

Author it with the pre-installed `$library` package and the standard library. Design the layout to fit the content; you are not filling a template.
$focus
Work in this order:

1. Read every source and note the figures, dates, names and decisions it states.
2. Decide the deck: its slides, their order, and which facts go on each. Prefer the specific figure over the general statement.
3. Write the script that builds exactly that deck, following the authoring rules below.
4. Read the script back and check it runs: every name imported, every value defined before use, the file saved at `OUTPUT_PATH`.

Grounding rules:

- Put only facts the sources state into the deck. No outside knowledge, no estimates, no placeholder text such as "Lorem ipsum" or "TBD".
- If a source calls something proposed, pending or a draft, label it that way in the deck.

$skill

The contract:

- The first line is a comment naming the deck: `# title: <a short title>`.
- The script runs alone, from an empty folder, for at most $seconds seconds. It cannot read the sources: write the content into the script.
- Save the file at the path in the `OUTPUT_PATH` environment variable.
- Use only the standard library and $library. No network.

Return only the Python code. No prose before it, no explanation after it, no markdown fence around it.
"""
)


def focus(user_prompt: str | None, limit: int = 500) -> str:
    """The user's request as a one-line emphasis; empty when there is none."""
    if not user_prompt or not user_prompt.strip():
        return ""
    request = " ".join(user_prompt.split())[:limit]
    return f"\nThe person asking wants this emphasis: {request}\n"


def build(user_prompt: str | None = None) -> str:
    return TEMPLATE.substitute(
        label=LABEL,
        library=LIBRARY,
        focus=focus(user_prompt),
        skill=PPTX_SKILL,
        seconds=SCRIPT_SECONDS,
    )
