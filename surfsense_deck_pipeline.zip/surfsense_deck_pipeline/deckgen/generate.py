"""Step 4 - generate: ask the model for the script and read its reply.

SurfSense sends one system prompt plus the grounding (the sources) as a single
user message, then collects the reply (`worker/studio/shared/generate.py`). It
reaches 100+ models through LiteLLM / the OpenAI spec. Here there are two thin
clients (Anthropic, and any OpenAI-compatible endpoint such as Ollama or vLLM)
and a scripted one for tests.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Protocol

from deckgen.models import Source


@dataclass(frozen=True)
class Message:
    role: str  # "system" | "user" | "assistant"
    content: str


class LLM(Protocol):
    def complete(self, messages: list[Message]) -> str: ...


# -- building what is sent --------------------------------------------------


def grounding(sources: list[Source]) -> str:
    """The sources as one block: a heading per document, then its text."""
    if not sources:
        return "(no sources)"
    return "\n\n".join(f"# Source: {s.title}\n\n{s.content}" for s in sources)


def build_messages(system: str, sources: list[Source]) -> list[Message]:
    return [Message("system", system), Message("user", grounding(sources))]


def run_model(llm: LLM, system: str, sources: list[Source]) -> str:
    return llm.complete(build_messages(system, sources))


# -- reading the reply ------------------------------------------------------

_FENCE = re.compile(r"```(?:python|py)?[ \t]*\n(.*?)```", re.DOTALL)
_TITLE = re.compile(r"^\s*#\s*title:\s*(.+?)\s*$", re.IGNORECASE)


def script_reply(raw: str) -> str:
    """The script itself: the prompt forbids a fence, but a model may add one anyway."""
    text = raw.strip()
    fenced = _FENCE.search(text)
    if fenced:
        return fenced.group(1).strip()
    return text


def script_title(script: str) -> str | None:
    """The name from the required `# title:` first line; None when it is missing."""
    for line in script.splitlines()[:5]:
        match = _TITLE.match(line)
        if match:
            return match.group(1)[:200]
    return None


# -- clients ----------------------------------------------------------------


class AnthropicLLM:
    """Needs `pip install anthropic` and ANTHROPIC_API_KEY."""

    def __init__(self, model: str | None = None, max_tokens: int = 16_000) -> None:
        import anthropic

        self._client = anthropic.Anthropic()
        self._model = model or os.environ.get("DECKGEN_MODEL", "claude-sonnet-5-5")
        self._max_tokens = max_tokens

    def complete(self, messages: list[Message]) -> str:
        system = "\n\n".join(m.content for m in messages if m.role == "system")
        turns = [{"role": m.role, "content": m.content} for m in messages if m.role != "system"]
        parts: list[str] = []
        with self._client.messages.stream(
            model=self._model, max_tokens=self._max_tokens, system=system, messages=turns
        ) as stream:
            for text in stream.text_stream:
                parts.append(text)
        return "".join(parts)


class OpenAICompatibleLLM:
    """Needs `pip install openai`. `base_url` points at Ollama, vLLM, LiteLLM and the like."""

    def __init__(self, model: str, base_url: str | None = None, api_key: str | None = None) -> None:
        import openai

        self._client = openai.OpenAI(
            base_url=base_url or os.environ.get("OPENAI_BASE_URL"),
            api_key=api_key or os.environ.get("OPENAI_API_KEY", "not-needed"),
        )
        self._model = model

    def complete(self, messages: list[Message]) -> str:
        reply = self._client.chat.completions.create(
            model=self._model, messages=[{"role": m.role, "content": m.content} for m in messages]
        )
        return reply.choices[0].message.content or ""


class ScriptedLLM:
    """Returns canned replies in order; records what it was sent. For tests and dry runs."""

    def __init__(self, *replies: str) -> None:
        self._replies = list(replies)
        self.calls: list[list[Message]] = []

    def complete(self, messages: list[Message]) -> str:
        self.calls.append(messages)
        return self._replies.pop(0) if self._replies else ""
