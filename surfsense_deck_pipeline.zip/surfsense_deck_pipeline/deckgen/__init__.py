"""Steps 1-4 of SurfSense's document-to-deck flow: ingest, gather, prompt, generate."""

from deckgen.pipeline import DraftResult, draft_script, prepare, read_documents

__all__ = ["DraftResult", "draft_script", "prepare", "read_documents"]
