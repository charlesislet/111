"""Step 2 - gather: cut the selected documents to a fixed character budget.

The rules follow SurfSense's `worker/studio/shared/gather.py`:

1. A selection that fits the budget is sent whole.
2. One that does not gives every document an even share, so none is left out.
   With a query, each share holds that document's passages that best match it;
   without one, the document's start.
3. When the even share would fall below MIN_SHARE_CHARS, the selection's best
   passages for the query (else a default focus) are taken across all documents
   instead, and only documents holding one are returned.

SurfSense ranks passages with its database's hybrid (semantic + full-text)
search. This stand-in ranks them with a small BM25 over the candidate chunks,
which needs no index and handles CJK text through character bigrams.
"""

from __future__ import annotations

import math
import re
from collections import Counter

from deckgen.models import Document, Source

BUDGET_CHARS = 24_000
MIN_SHARE_CHARS = 1_500
CHUNK_CHARS = 1_900  # about one 480-token chunk
DEFAULT_FOCUS = "the main points, findings, figures and conclusions"
GAP = "\n\n[...]\n\n"


def gather(
    documents: list[Document],
    query: str | None = None,
    *,
    budget_chars: int | None = None,
    focus: str | None = None,
) -> list[Source]:
    budget = budget_chars or BUDGET_CHARS
    chosen = [d for d in _unique(documents) if d.content]
    if not chosen:
        return []
    if sum(len(d.content) for d in chosen) <= budget:
        return [_whole(d) for d in chosen]

    share = budget // len(chosen)
    if share < MIN_SHARE_CHARS:
        search_for = query if query and query.strip() else focus or DEFAULT_FOCUS
        return _best_passages(chosen, search_for, budget)

    sources = []
    for document in chosen:
        text = _best_of_one(document, query, share) if query and query.strip() else document.content[:share]
        sources.append(Source(document.id, document.title, text))
    return sources


def _unique(documents: list[Document]) -> list[Document]:
    seen: set[int] = set()
    out = []
    for document in documents:
        if document.id not in seen:
            seen.add(document.id)
            out.append(document)
    return out


def _whole(document: Document) -> Source:
    return Source(document.id, document.title, document.content)


# -- chunking and ranking ---------------------------------------------------


def chunks(text: str, size: int = CHUNK_CHARS) -> list[str]:
    """Paragraph-aligned pieces of at most `size` characters."""
    pieces: list[str] = []
    current = ""
    for paragraph in re.split(r"\n\s*\n", text):
        paragraph = paragraph.strip()
        if not paragraph:
            continue
        while len(paragraph) > size:  # one very long paragraph
            if current:
                pieces.append(current)
                current = ""
            pieces.append(paragraph[:size])
            paragraph = paragraph[size:]
        if current and len(current) + 2 + len(paragraph) > size:
            pieces.append(current)
            current = ""
        current = f"{current}\n\n{paragraph}" if current else paragraph
    if current:
        pieces.append(current)
    return pieces


_WORD = re.compile(r"[A-Za-z0-9_]+")
_CJK = re.compile(r"[㐀-鿿]+")


def tokens(text: str) -> list[str]:
    text = text.lower()
    out = _WORD.findall(text)
    for run in _CJK.findall(text):
        out += [run] if len(run) == 1 else [run[i : i + 2] for i in range(len(run) - 1)]
    return out


def rank(pieces: list[str], query: str) -> list[int]:
    """Indexes of `pieces`, best match first (BM25). Ties keep document order."""
    if not pieces:
        return []
    docs = [Counter(tokens(p)) for p in pieces]
    lengths = [sum(c.values()) or 1 for c in docs]
    average = sum(lengths) / len(lengths)
    n = len(pieces)
    scores = [0.0] * n
    for term in set(tokens(query)):
        holding = sum(1 for c in docs if term in c)
        if not holding:
            continue
        idf = math.log(1 + (n - holding + 0.5) / (holding + 0.5))
        for i, counts in enumerate(docs):
            f = counts.get(term, 0)
            if f:
                scores[i] += idf * f * 2.5 / (f + 1.5 * (0.25 + 0.75 * lengths[i] / average))
    return sorted(range(n), key=lambda i: (-scores[i], i))


def _take(pieces: list[str], order: list[int], budget: int) -> list[int]:
    """Greedy: the best-ranked pieces that still fit, returned in document order."""
    used, kept = 0, []
    for i in order:
        cost = len(pieces[i]) + len(GAP)
        if used + cost <= budget:
            kept.append(i)
            used += cost
    return sorted(kept)


def _join(pieces: list[str], kept: list[int]) -> str:
    """Passages in document order; [...] only where two were not adjacent."""
    out = ""
    for k, i in enumerate(kept):
        if k:
            out += "\n\n" if kept[k - 1] == i - 1 else GAP
        out += pieces[i]
    return out


def _best_of_one(document: Document, query: str, share: int) -> str:
    pieces = chunks(document.content)
    kept = _take(pieces, rank(pieces, query), share)
    # A single chunk larger than the share would leave nothing: fall back to the start.
    return _join(pieces, kept) if kept else document.content[:share]


def _best_passages(documents: list[Document], search_for: str, budget: int) -> list[Source]:
    pool: list[tuple[int, str]] = []  # (document index, chunk)
    for index, document in enumerate(documents):
        pool += [(index, piece) for piece in chunks(document.content)]
    order = rank([piece for _, piece in pool], search_for)
    kept = _take([piece for _, piece in pool], order, budget)

    by_document: dict[int, list[int]] = {}
    for i in kept:
        by_document.setdefault(pool[i][0], []).append(i)
    pieces = [piece for _, piece in pool]
    return [
        # `kept` is in pool order, and a document's chunks are consecutive in the pool,
        # so adjacency in the pool is adjacency in the document.
        Source(documents[index].id, documents[index].title, _join(pieces, indexes))
        for index, indexes in sorted(by_document.items())
    ]
