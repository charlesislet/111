import tempfile
import unittest
from pathlib import Path

from deckgen import gather, generate, ingest, pipeline, prompt
from deckgen.models import Document


def doc(i, text, title=None):
    return Document(i, title or f"doc{i}", text)


def paragraphs(prefix, count, size=400):
    return "\n\n".join(f"{prefix} paragraph {k}. " + "x" * size for k in range(count))


class GatherTests(unittest.TestCase):
    def test_fits_budget_sent_whole(self):
        out = gather.gather([doc(1, "short"), doc(2, "also short")], budget_chars=1000)
        self.assertEqual([s.content for s in out], ["short", "also short"])

    def test_even_share_without_query_takes_the_start(self):
        a, b = doc(1, "A" * 10_000), doc(2, "B" * 10_000)
        out = gather.gather([a, b], budget_chars=6_000)
        self.assertEqual([len(s.content) for s in out], [3_000, 3_000])
        self.assertTrue(out[0].content.startswith("A"))

    def test_even_share_with_query_picks_matching_passages(self):
        text = paragraphs("filler", 20) + "\n\nThe revenue forecast for Q3 is 4.2 million.\n\n" + paragraphs("more", 20)
        out = gather.gather([doc(1, text), doc(2, "tiny second doc")], "revenue forecast", budget_chars=6_000)
        self.assertIn("4.2 million", out[0].content)
        self.assertLessEqual(len(out[0].content), 3_000)

    def test_small_share_switches_to_best_passages_and_drops_empty_docs(self):
        relevant = doc(1, paragraphs("noise", 10) + "\n\nGross margin reached 61 percent.\n\n" + paragraphs("noise", 10))
        irrelevant = [doc(i, paragraphs("zzz", 12)) for i in range(2, 12)]
        out = gather.gather([relevant, *irrelevant], "gross margin", budget_chars=9_000)  # share = 818 < 1500
        self.assertIn("Gross margin reached 61 percent", "".join(s.content for s in out))
        self.assertLess(len(out), 11)
        self.assertLessEqual(sum(len(s.content) for s in out), 9_000)

    def test_cjk_query_matches(self):
        text = paragraphs("無關", 20, 200) + "\n\n第三季營收預測為四千二百萬元。\n\n" + paragraphs("其他", 20, 200)
        out = gather.gather([doc(1, text), doc(2, "短")], "營收預測", budget_chars=4_000)
        self.assertIn("四千二百萬元", out[0].content)

    def test_duplicates_and_empty_documents_ignored(self):
        out = gather.gather([doc(1, "a"), doc(1, "a"), doc(2, "")])
        self.assertEqual(len(out), 1)


class IngestTests(unittest.TestCase):
    def test_text_and_html(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / "n.md").write_text("# Title\n\nbody", encoding="utf-8")
            (Path(d) / "p.html").write_text("<h1>Hi</h1><script>x()</script><p>there</p>", encoding="utf-8")
            self.assertEqual(ingest.ingest(Path(d) / "n.md", 1).content, "# Title\n\nbody")
            self.assertEqual(ingest.ingest(Path(d) / "p.html", 2).content, "Hi\n\nthere")

    def test_pptx_roundtrip(self):
        from pptx import Presentation

        with tempfile.TemporaryDirectory() as d:
            prs = Presentation()
            slide = prs.slides.add_slide(prs.slide_layouts[1])
            slide.shapes.title.text = "Plan"
            slide.placeholders[1].text = "Ship it"
            prs.save(Path(d) / "x.pptx")
            text = ingest.ingest(Path(d) / "x.pptx", 1).content
            self.assertIn("## Slide 1: Plan", text)
            self.assertIn("Ship it", text)

    def test_unsupported(self):
        with tempfile.TemporaryDirectory() as d:
            (Path(d) / "a.xyz").write_text("?")
            with self.assertRaises(ingest.UnsupportedFormatError):
                ingest.ingest(Path(d) / "a.xyz", 1)


class PromptTests(unittest.TestCase):
    def test_contract_present(self):
        text = prompt.build()
        for needle in ("# title:", "OUTPUT_PATH", "python-pptx", "120 seconds", "No network", "Return only the Python code"):
            self.assertIn(needle, text)

    def test_no_unresolved_template_names(self):
        self.assertNotRegex(prompt.build("x"), r"\$[a-z]+")

    def test_focus_included_only_with_a_request(self):
        self.assertNotIn("emphasis", prompt.build())
        self.assertIn("5 分鐘摘要", prompt.build("給主管的 5 分鐘摘要"))


class GenerateTests(unittest.TestCase):
    def test_fence_stripped_and_title_read(self):
        raw = "```python\n# title: Q3 Review\nimport os\n```"
        script = generate.script_reply(raw)
        self.assertEqual(script, "# title: Q3 Review\nimport os")
        self.assertEqual(generate.script_title(script), "Q3 Review")

    def test_title_missing(self):
        self.assertIsNone(generate.script_title("import os"))

    def test_messages_shape(self):
        msgs = generate.build_messages("SYS", [gather.Source(1, "A", "body")])
        self.assertEqual([m.role for m in msgs], ["system", "user"])
        self.assertIn("# Source: A", msgs[1].content)


class PipelineTests(unittest.TestCase):
    def test_draft_script_end_to_end_with_scripted_model(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "report.md"
            f.write_text("Revenue grew 12% in Q3.", encoding="utf-8")
            llm = generate.ScriptedLLM("```python\n# title: Q3\nimport os\nprint(os.environ)\n```")
            result = pipeline.draft_script([f], llm, "Q3 summary")
            self.assertEqual(result.title, "Q3")
            self.assertIsNone(result.syntax_error)
            system, user = llm.calls[0]
            self.assertIn("Q3 summary", system.content)
            self.assertIn("Revenue grew 12%", user.content)

    def test_empty_reply_raises_and_bad_syntax_is_flagged(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "a.txt"
            f.write_text("x", encoding="utf-8")
            with self.assertRaises(pipeline.EmptyScriptError):
                pipeline.draft_script([f], generate.ScriptedLLM("   "))
            bad = pipeline.draft_script([f], generate.ScriptedLLM("def (:\n"))
            self.assertIsNotNone(bad.syntax_error)
            self.assertEqual(bad.title, "a")  # falls back to the source's name


if __name__ == "__main__":
    unittest.main()
