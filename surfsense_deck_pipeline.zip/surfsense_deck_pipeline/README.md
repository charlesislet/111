# deckgen：SurfSense 簡報生成流程，步驟 1–4

把文件變成「由 LLM 寫成的 python-pptx 腳本」。到腳本產出為止；步驟 5（沙盒執行）、6（失敗修復）、7（存檔索引）沒有實作。

| 步驟 | 檔案 | 對應 SurfSense 原始碼 |
|---|---|---|
| 1 入庫 | `deckgen/ingest.py` | `worker/ingestion`（它用 Docling 等解析器並寫入資料庫，這裡只做檔案轉 Markdown） |
| 2 收集素材 | `deckgen/gather.py` | `worker/studio/shared/gather.py`（預算 24,000 字元、每份最低 1,500、改選最佳段落的規則一致；排序用 BM25 取代它的資料庫混合搜尋） |
| 3 組 prompt | `deckgen/prompt.py` | `worker/studio/office/prompt.py`、`pptx/SKILL.md`（結構與規則相同，文字是自己寫的） |
| 4 產生腳本 | `deckgen/generate.py`、`deckgen/pipeline.py` | `worker/studio/shared/generate.py`、`office/pipeline.py` 的 `render` 前半 |

## 使用

```bash
# 只跑步驟 1–3，印出會送給模型的內容（不需要 API key）
python -m deckgen report.pdf notes.md -p "給主管的 5 分鐘摘要" --dry-run

# 跑到步驟 4，把腳本寫到檔案
pip install anthropic pypdf python-docx python-pptx
export ANTHROPIC_API_KEY=...
python -m deckgen report.pdf -p "給主管的 5 分鐘摘要" -o draft_script.py

# 本地模型（Ollama、vLLM 等 OpenAI 相容端點）
pip install openai
python -m deckgen report.pdf --provider openai --model qwen2.5:14b --base-url http://localhost:11434/v1
```

在 Python 裡：

```python
from deckgen import draft_script
from deckgen.generate import AnthropicLLM

result = draft_script(["report.pdf"], AnthropicLLM(), "給主管的 5 分鐘摘要")
print(result.title, result.syntax_error)
open("draft_script.py", "w").write(result.script)
```

`result.script` 就是下一步（步驟 5）要拿去執行的文字：它會讀 `OUTPUT_PATH` 環境變數，把 .pptx 存到那裡。
執行前請先看過內容，這是模型寫的程式碼。

## 測試

```bash
python -m unittest discover -s tests -v
```

## 與原版的差異

- 沒有資料庫與向量索引；段落排序用 BM25（支援 CJK 字元二連詞）。
- `ingest.py` 只處理 txt/md/csv/json/html/pdf/docx/pptx。
- 模型端：Anthropic 與 OpenAI 相容端點兩種，沒有 LiteLLM 的路由與模型等級（compact/capable/frontier）提示變體。
- `pipeline.draft_script` 多做了一個 `ast.parse` 語法檢查（不執行腳本），結果放在 `syntax_error`。
